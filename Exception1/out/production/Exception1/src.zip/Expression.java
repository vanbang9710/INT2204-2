public abstract class Expression {
    /**
     * toString.
     */
    public abstract String toString();

    /**
     * evaluate.
     */
    public abstract double evaluate();
}
