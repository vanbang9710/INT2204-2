public class Division extends BinaryExpression {
    /**
     * Constructor.
     */
    public Division(Expression left, Expression right) {
        super(left, right);
    }

    /**
     * toString.
     */
    public String toString() {
        return "(" + left.toString() + " / " + right.toString() + ")";
    }

    /**
     * evaluate.
     */
    public double evaluate() {
        try {
            int v = (int)left.evaluate() / (int)right.evaluate();
            return left.evaluate() / right.evaluate();
        } catch (ArithmeticException e) {
            //System.out.println("Lỗi chia cho 0");
            //System.out.println("Error: " + e.getMessage());
            return left.evaluate();
        }
    }
}
